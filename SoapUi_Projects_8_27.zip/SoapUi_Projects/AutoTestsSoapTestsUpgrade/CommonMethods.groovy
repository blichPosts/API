
// Bob Lichtenfels 12/18/15 - Updated ReadUserIds to setup Logo Url. Logo Url has three colons ":".
// Bob Lichtenfels 2/25/16 - Add methods for Href testing.


package soapUIScripts
import java.util.Date;


class CommonMethods
{
	def log;
	def testRunner;
	
	CommonMethods(log, testRunner)
	{
		log.info "Startup CommonMethods Object."
		this.log = log;
		this.testRunner = testRunner
	}

	static boolean StaticMethod(log)
	{
		log.info "RUN STATIC METHOD ***********************************************..."
		return false
	}		
		
	def static SetupTestCaseProperties(log)
	{
		log.info  "here in SetupTestCaseProperties"
	}
		
	// read in user ids and assign to test case properties.
	static boolean ReadUserIds(fileName, log, testRunner)
	{
		def localVar
		def localArr = []
		def finalVar
		try
		{
			new File(fileName).eachLine 
			{ 
				line ->	
				//log.info line
				localVar = line
				localArr = localVar.split(":")
				if(localArr[0] == "LogoUrl" || localArr[0] == "MainEndpoint" || localArr[0] == "URL" || localArr[0] == "URLtoken") // this array will have two colons ":".
				{
					testRunner.testCase.setPropertyValue(localArr[0],localArr[1] + ":" + localArr[2])				
				}
				else
				{
					testRunner.testCase.setPropertyValue(localArr[0],localArr[1])
				}	
			}
		}
		catch (all)
		{
			log.info "    File read failed in ReadUserIds method."
			return false
		}
		return true
	}

	// read in user ids, URL, info and assign to test case properties.
	static boolean ReadUserIdsURL(fileName, log, testRunner)
	{
		def localVar
		def localArr = []
		def finalVar
		try
		{
			new File(fileName).eachLine 
			{ 
				line ->	
				//log.info line
				localVar = line
				localArr = localVar.split(":")
				if(localArr[0] == "LogoUrl" || localArr[0] == "URL" || localArr[0] == "URLtoken") // this array will have two colons ":".
				{
					testRunner.testCase.setPropertyValue(localArr[0],localArr[1] + ":" + localArr[2])				
				}
				else
				{
					if(localArr[1] == "NULL")
					{
						testRunner.testCase.setPropertyValue(localArr[0],"")					
					}
					else
					{
						testRunner.testCase.setPropertyValue(localArr[0],localArr[1])
					}
				}	
			}
		}
		catch (all)
		{
			log.info "    File read failed in ReadUserIds method."
			return false
		}
		return true
	}
	
	// read in each line of token pair file and send to SetupTestSuiteVariables method for creating token pair file.
	//static boolean ReadTokenPair(fileName)
	boolean ReadTokenPair(fileName)
	{
		try
		{
			new File(fileName).eachLine 
			{ 
				line ->	
				//log.info line
				SetupTestSuiteVariables(line)
			}
		}
		catch (all)
		{
			log.info "    File read failed in ReadTokenPair method."
			return false
		}
		return true
	}

	// put token into test suite property if line contains one of the tokens.
	void SetupTestSuiteVariables(inputLine)
	{
		def strArray = []
		strArray = inputLine.split("=")
		if (inputLine.contains("AccessToken"))
		{
			// log.info strArray[1]
			testRunner.testCase.setPropertyValue("AccessToken",strArray[1])
			log.info "Access Token:" + testRunner.testCase.getPropertyValue("AccessToken")		
		}
		else if(inputLine.contains("RefreshToken"))
		{
			//log.info strArray[1]
			testRunner.testCase.setPropertyValue("RefreshToken",strArray[1])
			log.info "Refresh Token:" + testRunner.testCase.getPropertyValue("RefreshToken")				
		}
	}
	
	// read in each line of token pair file and send to SetupTestSuiteVariables method for creating token pair file.
	static boolean ReadTokenPair(fileName, log, testRunner)
	{
		try
		{
			new File(fileName).eachLine 
			{ 
				line ->	
				//log.info line
				SetupTestSuiteVariables(line ,log, testRunner)
			}
		}
		catch (all)
		{
			log.info "    File read failed in ReadTokenPair method."
			return false
		}
		return true
	}
	
	// put token into test suite property if line contains one of the tokens.
	static void SetupTestSuiteVariables(inputLine, log, testRunner)
	{
		def strArray = []
		strArray = inputLine.split("=")
		if (inputLine.contains("AccessToken"))
		{
			// log.info strArray[1]
			testRunner.testCase.setPropertyValue("AccessToken",strArray[1])
			log.info "Access Token:" + testRunner.testCase.getPropertyValue("AccessToken")		
		}
		else if(inputLine.contains("RefreshToken"))
		{
			//log.info strArray[1]
			testRunner.testCase.setPropertyValue("RefreshToken",strArray[1])
			log.info "Refresh Token:" + testRunner.testCase.getPropertyValue("RefreshToken")				
		}
	}

	
	// this is special for post tests. this reads in all userc Ids and only assigns a selected 
	// user id (parameter "strSelectedId") to a test case property. the id also has quotes put around it. 
	static boolean ReadUserIdForPostTest(fileName, log, testRunner, strSelectedId)
	{
		def localVar
		def localArr = []
		def finalVar
		try
		{
			new File(fileName).eachLine 
			{ 
				line ->	
				//log.info line
				localVar = line
				localArr = localVar.split(":")
				if(localArr[0] == strSelectedId)
				{
					testRunner.testCase.setPropertyValue(localArr[0],"\"" + localArr[1]  + "\"") 
					// log.info localArr[0] + ":" + localArr[1]
				}
			}
		}
		catch (all)
		{
			log.info "    File read failed in ReadUserIds method."
			return false
		}
		return true
	}
	
	// this verifies the href json href link passed in has all the values passed in, after the values have adjustments made to
	// them to make it possible to locate each expected part of the href. the number of "&" characters is verified and then
	// the expected expected size of the json href link is checked.
	static void VerifyHrefPathAndParams(hrefLink, limit, offset, sortType, queryType, queryValue, expectedNumAmpersands, json, log)
	{
		//log.info json
		def limitStr = "limit=" + limit
		def offsetStr =  "offset=" + offset
		int totalNumCharsExpected = 0
		def sortStr = ""
		def queryStr = ""
		
		if(sortType == "true")
		{
			sortStr = "sortAscending=true"
		}
		else
		{
			sortStr = "sortAscending=false"		
		}
		
		// if queryStr OR query type is "", both should be ""
		if(queryType == "" || queryValue == "")
		{
			if(!(queryType == "" && queryValue == ""))
			{
				log.info "If one of Query Type and Query Value variables is empty then they both should be empty."
				throw new RuntimeException("If one of Query Type and Query Value variables is empty then they both should be empty.")
			}
		}
		else
		{
			queryStr = queryType + "=" + queryValue	
		}
		
		// now add all query items and href link to a list 
		def itemList = []
		itemList.add(limitStr)
		itemList.add(offsetStr)
		itemList.add(sortStr)	
		itemList.add(queryStr)	
		itemList.add(hrefLink)	

		// now go through each query item in the list and the href and make sure it is in the json response. also total up the number of characters.
		for(str in itemList)
		{
			if(!json.contains(str))
			{
				log.info "Item " + str + " is not found in the Href path. Throwing error in method 'VerifyHrefPathAndParams'"
				throw new RuntimeException("Item " + str + " is not found in the Href path. Throwing error in method 'VerifyHrefPathAndParams'")
			}
			totalNumCharsExpected += str.size()
		}

		if(!VerifyNumberOfAmpersands(expectedNumAmpersands, json)) // this verfies correct number of ampersands.
		{
				log.info "Number of ampersands in json response passed into 'VerifyHrefPathAndParams' method is incorrect"
				throw new RuntimeException("Number of ampersands in json response passed into 'VerifyHrefPathAndParams' method is incorrect")
		}

		// verify the total number of cbaracters that were verified in the json string equals the size of the actual json string.	
		if((totalNumCharsExpected + expectedNumAmpersands) != json.size())
		{
				log.info "String size " + json.size() + " of json response does not equal the number of cbaracters " +  (totalNumCharsExpected + expectedNumAmpersands) + " that were verified in method 'VerifyHrefPathAndParams'."
				throw new RuntimeException("String size of json response "  + json.size() + " does not equal the number of cbaracters " +  (totalNumCharsExpected + expectedNumAmpersands) + " that were verified in method 'VerifyHrefPathAndParams'.")
		}
	}

	// this finds the number of '&' characters and verifys if the json string passed in has the 
	// expected amount. returns true if expected amount is correct else false.
	static boolean VerifyNumberOfAmpersands(expectedNumberAmpersands, json)
	{
		StringBuilder strTest =  new StringBuilder(json)
		
		int pos = -1; // search starts at pos+1, so set pos to -1 to start search at zero
		int x = 0 // this will keep count of number of ampersands ("&")
		
		while (true) { // break out of the loop when there are no further matches
				pos = strTest.indexOf("&", pos+1); // Look for the desired character starting one character past the pos
		
				if (pos < 0) break; // If the character is not found, end the loop
				x++
		}
		if(x == expectedNumberAmpersands)
		{
			return true
		}
		else
		{
			return false
		}
	}
	
	// this calculates the offset value for an href end link when the main offset query value is set to zero.
	// it receives the limit value, total number of items available in the API call being used, and the log reference.
	// it returns the offset value.
	static def GetOffsetValueForHrefEnd(limit, totalItemsCount, log)
	{
		//log.info totalItemsCount
		int intTotal = totalItemsCount as int
		int intLimit = limit as int
		def offset = 0

		int numFullPages = intTotal/intLimit // get number of full pages.

		if (intTotal % intLimit != 0) // check to see if there is a page containg less than limit number of items.
		{
			offset = numFullPages * intLimit // there is a page containg less than limit number of items
		}
		else
		{
			offset = (numFullPages - 1) * intLimit  // there is a not page containg less than limit number of items
		}

		return offset

	}
	
	// get the value for the test case property passed in.
	static String GetTestCasePropertyValue(String strIn, testRunner)
	{
			return testRunner.testCase.getPropertyValue(strIn) 
	}
	
	
	// parameters are offset, limit, list with all the items in the API collection.
	def GetItemsInOffsetPage(offsetIn, limitIn , itemsIn)
	{
		int finalPage = 1
		int offset = offsetIn // NOTE: this is zero based. 
		int limit  = limitIn
		itemsList  = []
		itemsList = itemsIn
		itemsReturn = []

		
		boolean lastPageNotFullPage = false

		if(offset + 1 > itemsIn.size())
		{
			log.info "Offset passed in " + offset + " exceeds the last element in the collection list passed in."
			throw new RuntimeException("Offset passed in, " + offset + " ,exceeds the last element in the collection list passed in.")
			return 
		}
		
		// this will find a one-based integer page. the offset has one added to make it one based like the  page numbers.
		// this is the first step to finding the page number that contains the offest item.
		int page = ((offset + 1)/limit)
		
		// the integer page found above did not consider the possibilty of the offset being past the integer page found. 
		// The check below looks for a remainder. if there is a remainder, the actual page is one page past the value of the 
		// integer "page" variable found above.
		if((offset + 1).mod(limit) != 0) 
		{
			page++ 
		}

		// at this point the page containing the offset is the vaule of the integer "page" value. 
		// now we want to return all the items in the page that contains the offset item passed in from the caller. the page integer is one 
		// based and the list passed in is zero based. find the starting one-based location of the page section that contains the offset 
		// integer passed in. 
		int startIndex = (limit * page) - limit

		// now put items onto the list to be returned.
		for(x = startIndex; x < startIndex + limit; x++)
		{
			if(itemsIn[x] != null)
			{
				itemsReturn.add(itemsIn[x])
			}
		}

		return itemsReturn
	}
	
	
	// This method generates a unique external order number by appending the current time, in milliseconds, to "QAOrderNumber" string
	// E.g.: QAOrderNumber<time_in_millis>
	def static GenerateExternalOrderNumber()
	{

		String base = "QAOrderNumber"
		String extOrderNumber
		
		def date = new Date()
		def timeMillis = date.time
		
		extOrderNumber = base + timeMillis.toString()
		
		return extOrderNumber
		
	}

	// Used to sort items from a list, in ascending order
	def static sortListAscending(originalList, log){
		
		def sortedList = originalList
		def itemAux = ""
		int compare = 0
		int j = 0

		for(int i = 0; i < sortedList.size()-1; i++){

			j = i + 1
		
			compare = sortedList[i].compareTo(sortedList[j])
					
			if(compare > 0){
				
				itemAux = sortedList[j]
				sortedList[j] = sortedList[i]
				sortedList[i] = itemAux
				
			}
			
		}
		
		return sortedList
		
	}

	// Used to sort items from a list, in descending order
	def static sortListDescending(originalList, log){

		def sortedList = originalList
		def itemAux = ""
		int compare = 0
		int j = 0

		for(int i = 0; i < sortedList.size()-1; i++){

			j = i + 1
			compare = sortedList[i].compareTo(sortedList[j])
					
			if(compare < 0){
				
				itemAux = sortedList[j]
				sortedList[j] = sortedList[i]
				sortedList[i] = itemAux
				
			}

		}
		
		return sortedList

	}

	
}