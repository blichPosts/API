package soapUIScripts
 
class DudleyDorightDataActions
{
	def log;
	def testRunner;
	def static Tenant = "XX1"
	def static limit = "10"
	def static offset = "0"
	def static companyEmployeeId = "Dudley.Doright2.XX1"
	
	DudleyDorightDataActions(log, testRunner)
	{
		log.info "Startup DudleyDorightDataActions Object."		
		this.testRunner = testRunner
	}
	
	static void SetupTestCaseProperties(log, testRunner)
	{
		log.info "Setting up test case properties in DoRight external class 'SetupTestCaseProperties'."
		testRunner.testCase.setPropertyValue("Tenant", Tenant)		
		testRunner.testCase.setPropertyValue("limit", limit)			
		testRunner.testCase.setPropertyValue("offset", offset)			
		testRunner.testCase.setPropertyValue("companyEmployeeId", companyEmployeeId)			
	}
}